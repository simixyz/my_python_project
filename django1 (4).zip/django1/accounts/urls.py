from django.conf.urls import url
from django.urls import path
import accounts
import twitter
from .import views
from django.contrib.auth import login
from django.contrib.auth.views import LoginView

from .views import register

urlpatterns = [
   url('^$',views.home),
   url(r'^login/$', LoginView.as_view(template_name='accounts/login.html')),
   url('register/',views.register),
   url('login/',views.login),
   url('sen/', views.sentimental, name='sentimental'),
   path('<id>/',views.details,name='details'),



]
