from django.db import models

class Customers(models.Model):
    name= models.CharField(max_length=100)
    img= models.ImageField(upload_to='pics')
    desc=models.TextField(null=True,blank=True)
    link= models.CharField(max_length=200,default="http://example.com",null=True,blank=True)
    polarity= models.FloatField()
    subjectivity = models.FloatField()