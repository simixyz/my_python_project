import urllib

from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import auth,User
# Create your views here.
from accounts.models import Customers

import bs4

import tweepy
from django.shortcuts import render
from textblob import TextBlob
from accounts.models import Customers



def home(request):
    name= "hiih"
    args={"myname":name}
    return render(request,'accounts/home.html',args)

def register(request):
    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']

        user=User.objects.create_user(username=request.POST.get('username'),password=request.POST.get('password'),first_name=request.POST.get('first_name'),last_name=request.POST.get('last_name'),email=request.POST.get('email'))
        user.save();
        print("user created");
        return redirect('/account/login/')
    else:
        return render(request, 'accounts/register.html')

def login(request):
    return render(request, 'accounts/login.html')

def sentimental(request):
    print("sentiiii");
    subjectivity = 0
    polarity = 0
    cee = Customers.objects.all()
    for i in cee:
        print("iiii");
        consumer_key = 'DwX26Myn9aWDpo3q4FwCmDnCL'
        consumer_secret = 'lsnfF51WviiIjONLH25kQjh0iRAcISMM31zu3oXIdX1pvaJN70'
        access_token = '1253677692446072834-5IuZhB2bDCBO1qHRCYGK3XCbYGOqxi'
        access_token_secret = 'ouNtewDH401CP3kuQ92T2f60npi2dGy8K4954r2P3rNIy'
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
        auth.set_access_token(access_token, access_token_secret)
        api = tweepy.API(auth)
        public_tweets = api.search(i.name)
        print("senti");
        for tweet in public_tweets:
            print("i");
            print(tweet.text);
            analysis = TextBlob(tweet.text)
            polarity=polarity+analysis.polarity
            subjectivity=subjectivity+analysis.subjectivity
            print(analysis.sentiment);
            print("haiii");
        i.polarity = polarity
        i.subjectivity = subjectivity
        i.save()
        print("123456");
    return render(request, 'accounts/twitter.html')





def home(request):
    customers=Customers.objects.all();
    return render(request, 'accounts/home.html',{'customers':customers})

def details(request,id):
    print("hhjjjjh");
    custid=Customers.objects.get(id=id)
    print("hhnnnn");
    scrap_url=custid.link
    if custid.desc== "":
        source = urllib.request.urlopen(scrap_url).read()
        soup=bs4.BeautifulSoup(source,'lxml')
        txt=""
        for paragraph in soup.find_all('p'):
            block=str(paragraph.text)
            if block==None:
                pass
            else:
                txt+=(str(paragraph.text))

        custid.desc = txt
        custid.save()
        print("hiii")
    return render(request,'accounts/details.html',{"custid":custid})











