import tweepy
from django.shortcuts import render
from textblob import TextBlob
from accounts.models import Customers

subjectivity=0
polarity=0
cee = Customers.objects.all()

def tweets(request):
    for i in cee:
        consumer_key = 'DwX26Myn9aWDpo3q4FwCmDnCL'
        consumer_secret = 'lsnfF51WviiIjONLH25kQjh0iRAcISMM31zu3oXIdX1pvaJN70'
        access_token = '1253677692446072834-5IuZhB2bDCBO1qHRCYGK3XCbYGOqxi'
        access_token_secret = 'ouNtewDH401CP3kuQ92T2f60npi2dGy8K4954r2P3rNIy'
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
        auth.set_access_token(access_token, access_token_secret)
        api = tweepy.API(auth)
        public_tweets = api.search(i.name)
        for tweet in public_tweets:
            print(tweet.text)
            analysis = TextBlob(tweet.text)
            polarity=polarity+analysis.polarity
            subjectivity=subjectivity+analysis.subjectivity
            print(analysis.sentiment)
        i.polarity=polarity
        i.subjectivity=subjectivity
        i.save()
    return render(request, 'accounts/twitter.html')











