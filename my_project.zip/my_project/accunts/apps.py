from django.apps import AppConfig


class AccuntsConfig(AppConfig):
    name = 'accunts'
