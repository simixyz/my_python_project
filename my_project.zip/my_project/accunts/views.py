import urllib

import bs4
import tweepy
from textblob import TextBlob

from django.shortcuts import render, redirect
from django.contrib.auth.models import auth, User


# Create your views here.
from accunts.models import Customers


def home(request):
    custs = Customers.objects.all()
   # custs1 = Customers.objects.get().desc
    print('hiii')
   # print(custs.get().name)

    return render(request, "accounts/home.html",{'custs':custs})
   # return render(request, "accounts/home.html", {'custs1': custs1})


def login(request):
     if request.method=='POST':
         username = request.POST['username']
         password = request.POST['password']
         user=auth.authenticate(username=username,password=password)
         if user is not None:
             auth.login(request,user)


             return redirect('/accounts/home')
         else:
             print('invalid credentials')
             return redirect('/accounts/login')

     else:
      return render(request,'accounts/login.html')



def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        if password1==password2:
            if User.objects.filter(username=username).exists():
                print('username taken!...!')
            elif User.objects.filter(email=email).exists():
                print('email already exists...')
            else:
                 user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name,
                                        last_name=last_name)
                 user.save();
                 print('registered!!')
                 return redirect('/accounts/login')
        else:
            print('password not matching...')

    else:
        return render(request, 'accounts/register.html')

def details(request,id):
    custid=Customers.objects.get(id=id)
    print('hii')
    scrap_url = custid.link
    print('heloo')
    if custid.desc=="":
        source = urllib.request.urlopen(scrap_url).read()
        print('read')
        soup = bs4.BeautifulSoup(source,'lxml')
        txt = ""
        for paragraph in soup.find_all('p'):
            block = str(paragraph.text)
            if block == None:
                pass
            else:
                txt +=(str(paragraph.text))
        custid.desc = txt
        custid.save()

        print('scrapped')
    return render(request,"accounts/details.html",{'custid':custid})


def twitter_details(request):
   polarity =0
   subjectivity = 0
   cust = Customers.objects.all()
   for d in cust:
       print(d.name)
       consumer_key = 'C6TgMIfXntX7IWBzgbaYBgE86'
       consumer_secret = '2lgQMDHML5ujvfknBhS4PS8TAqNdwLVpnVPMaOw1kOnUBqTmNS'
       access_token = '1253200635769610240-na8CC41NF06Qs1mU7OdHg8REwdu4OR'
       access_token_secret = 'dIDfw0CfVucfAmSp5K7KOcpXbBsEXLiyTIjIMX1L3nMDP'
       auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
       auth.set_access_token(access_token, access_token_secret)
       api = tweepy.API(auth)
       public_tweets = api.search(d.name)
       for tweet in public_tweets:

           print(tweet.text)
           analysis = TextBlob(tweet.text)
           polarity  = polarity + analysis.polarity
           subjectivity = subjectivity + analysis.subjectivity
       d.polarity = polarity
       d.subjectivity = subjectivity
       d.save()
       print(polarity)
       print(subjectivity)
   return render(request, 'accounts/sentiment.html')
