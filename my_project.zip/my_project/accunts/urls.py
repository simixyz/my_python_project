from django.conf import settings
from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth.views import LoginView
from django.templatetags.static import static
from django.urls import path

from . import views

urlpatterns = [
     #url(r'^$', views.home),
       path("home", views.home, name="home"),
#url(r'^login/$', LoginView.as_view(template_name='accounts/login.html'), name='login'),
    # url(r'^login/$',login,{'template_name':'accounts/login.html'}),
     url(r'^admin/', admin.site.urls),
   path("register",views.register,name="register"),
path("login",views.login,name="login"),
    path("<id>/",views.details,name='id'),
    path("sentiment", views.twitter_details, name='sentiment'),

     ]
